#!/bin/sh
wget http://dygraphs.com/excanvas.js
rm excanvas.js.*
wget http://dygraphs.com/dygraph-combined.js
rm dygraph-combined.js.*
